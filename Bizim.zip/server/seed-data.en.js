/* ======================================================
   ERSOY SPORTS — İngilizce başlangıç içeriği
   seed-data.js'in birebir karşılığı. Yalnızca Türkçesi hâlâ ilk hâlinde olan
   alanlara uygulanır (yönetici Türkçeyi değiştirdiyse eski çeviri basılmaz).
   ====================================================== */

export const SEED_EN = Object.freeze({
  subtitles: [
    ["— Why the cage?", "— They said the match would be exciting."],
    ["— What time's kick-off?", "— 20:00. By 20:01 it'll have started."],
    ["— Who are you supporting?", "— The winner. I'll tell you after the match."],
    ["— Was that a goal?", "— Sort of. Let's watch the replay."],
    ["— Did the stream freeze?", "— No. I froze. Excitement."],
    ["— Comfortable?", "— My head is very relaxed."],
  ],

  quotes: [
    "The ball is round. I checked.",
    "I don't understand offside, but I respect it.",
    "There's stoppage time. Why is there no shortage time?",
    "I held my breath for the penalty. Still holding it.",
    "The referee blew his whistle. So did I. The neighbour came over.",
    "A draw is also a result. Nobody should be sad.",
    "I counted the corner flags. Four. Always four.",
  ],

  liveComments: [
    "The ball is in midfield right now. Nice spot.",
    "The right-back is running. I don't know why, but I support it.",
    "The referee showed something. I couldn't see what.",
    "The keeper adjusted his gloves. So did I. I don't have gloves.",
    "Throw-in. Nothing was thrown out first. Curious.",
  ],

  commentary: [
    { ago: 1, text: "A player tied his boot. Double knot. I approve." },
    { ago: 4, text: "The referee checked his watch. So did I. Same time." },
    { ago: 9, text: "The ball went out, then came back. I was pleased." },
    { ago: 15, text: "The stands are singing. I don't know the words, but the rhythm is good." },
    { ago: 22, text: "Someone is warming up on the touchline. It isn't cold. I'm curious." },
    { ago: 34, text: "The broadcast has started. I checked. Twice." },
    { ago: 41, text: "Warm-up's over. I didn't warm up. No need, I'm not playing." },
    { ago: 47, text: "The teams are out. I counted: twenty-two. Twenty-three with the referee." },
    { ago: 53, text: "The stadium lights came on. I switched on my lamp. Same moment." },
    { ago: 58, text: "Brewed my pre-match tea. They said 90+5 minutes would do." },
  ],

  tickerNotes: [
    "I checked the scores one by one. All correct.",
    "Derby at 20:00. Be ready at 19:59.",
    "I counted the minutes too. No problems.",
  ],

  tickerAds: [
    "Patience Tea — brews for 90+5 minutes.",
    "Cage Helmet — full protection against match excitement.",
  ],

  rentCopies: [
    { brand: "Space for rent", tagline: "Your brand here, right next to Ersoy.", note: "Ersoy measured this spot. Twice.", cta: "Rent it now" },
    { brand: "Your ad here", tagline: "Ersoy checked: this spot is empty.", note: "He finds that strange too.", cta: "Get in touch" },
    { brand: "This space is waiting", tagline: "Daily, weekly, monthly rentals.", note: "Ersoy worked out the prices. He'll tell you.", cta: "Get a quote" },
    { brand: "Ad space for rent", tagline: "Everyone watching the match looks here too.", note: "Ersoy says so. He counted.", cta: "Advertise" },
    { brand: "This space is empty", tagline: "Ersoy wanted to put something here. He couldn't.", note: "You can.", cta: "Book your spot" },
    { brand: "The window is yours", tagline: "It gets very crowded here on derby day.", note: "Ersoy is waiting in a tuxedo.", cta: "Rent" },
  ],

  // Parodi markalar (kurgusal)
  creatives: {
    "kafes-kask": { brand: "Cage Helmet", tagline: "Full protection against match excitement.", note: "Ersoy approved. He wears one himself.", cta: "Protect your head" },
    "sabir-cayi": { brand: "Patience Tea", tagline: "Brews for 90+5 minutes.", note: "Stoppage time included.", cta: "Start brewing" },
    "detay-optik": { brand: "Detail Optics", tagline: "Can't see offside?", note: "Neither can we. But our glasses look great.", cta: "Pick glasses" },
    "derbi-smokin": { brand: "Derby Tuxedo", tagline: "You attend a derby in a tuxedo.", note: "Don't ask. Rentals available.", cta: "Try it on" },
    "ersoy-corap": { brand: "Ersoy Socks", tagline: "The referee's choice.", note: "Ersoy noticed. You will too.", cta: "Get a pair" },
  },
  clickNote: "Ersoy clicked this ad too. Nothing happened. (Template ad — you'll add the real link.)",

  // Lig adlarının İngilizcesi (Türkçesi → İngilizcesi; resmî adı aynı olanlar listede yok)
  leagues: {
    "Premier Lig": "Premier League",
    "Arjantin Primera División": "Argentine Primera División",
    "Brezilya Serie A": "Brazilian Série A",
    "NBA Hazırlık": "NBA Preseason",
  },

  // Kanal kimliği → İngilizce tür / şimdi / sonra
  channels: {
    "ch-1": { genre: "Football", now: "Beşiktaş – Trabzonspor", next: "Post-match: Ersoy counts the corners one by one" },
    "ch-2": { genre: "Basketball", now: "Anadolu Efes – Fenerbahçe Beko", next: "02:30 · Cavaliers – Magic" },
    "ch-3": { genre: "Volleyball", now: "VakıfBank – Eczacıbaşı Dynavit", next: "21:00 · Halkbank – Ziraat Bankkart" },
    "ch-4": { genre: "Derby channel", now: "Real Madrid – Barcelona", next: "20:00 · Galatasaray – Fenerbahçe" },
    "ch-5": { genre: "Legendary matches", now: "Unforgettable derbies (replay)", next: "Ersoy's favourite 0–0s" },
    "ch-6": { genre: "Studio", now: "Ersoy explains why the ball is round", next: "Guest: the referee's sock" },
  },

  site: {
    tagline: "In the stands, sort of.",
    description: "Ersoy Sports: live matches, today's fixtures and Ersoy's overly detailed commentary. In the stands, sort of.",
    contactNote: "Message us on Telegram. Ersoy replies — after some thought.",
  },
  derby: { prediction: "My prediction: 1–1. If not, it'll be some score. That much is certain." },
  images: {
    heroAlt: "A still from the series Gibi: a bearded man smiling with his eyes closed, a metal cage on his head, kissed on the cheek by a woman with curly hair.",
    cardAlt: "A still from the series Gibi: a curly-haired bearded man in a tuxedo and bow tie.",
  },
});

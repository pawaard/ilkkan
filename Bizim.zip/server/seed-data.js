/* ======================================================
   ERSOY SPORTS — Başlangıç içeriği (veritabanı tohumu)
   Maçlar, kanallar ve Ersoy'un replikleri burada.
   İlk açılışta veritabanına yüklenir; sonrasında içerik /yonetim panelinden yönetilir.
   ====================================================== */

export const SEED = Object.freeze({
  categories: [
    { id: "all", label: "Hepsi" },
    { id: "futbol", label: "Futbol" },
    { id: "basketbol", label: "Basketbol" },
    { id: "voleybol", label: "Voleybol" },
    { id: "kanal", label: "Kanallar" },
  ],

  /*
    status: "live" | "upcoming" | "finished"
    clock:  kısa durum (bilet koçanında görünür)
    period: uzun durum (oynatıcıda görünür)
    score:  [ev, deplasman] — başlamamış maçta null
  */
  matches: [
    { id: "bjk-ts", cat: "futbol", league: "Trendyol Süper Lig", home: "Beşiktaş", away: "Trabzonspor", homeShort: "BJK", awayShort: "TS", time: "19:00", status: "live", clock: "34'", period: "34. dakika", score: [1, 0] },
    { id: "rma-bar", cat: "futbol", league: "LaLiga", home: "Real Madrid", away: "Barcelona", homeShort: "RMA", awayShort: "BAR", time: "18:15", status: "live", clock: "71'", period: "71. dakika", score: [2, 2] },
    { id: "mci-liv", cat: "futbol", league: "Premier Lig", home: "Manchester City", away: "Liverpool", homeShort: "MCI", awayShort: "LIV", time: "18:30", status: "live", clock: "61'", period: "61. dakika", score: [1, 1] },
    { id: "bay-bvb", cat: "futbol", league: "Bundesliga", home: "Bayern München", away: "Borussia Dortmund", homeShort: "BAY", awayShort: "BVB", time: "18:30", status: "live", clock: "58'", period: "58. dakika", score: [0, 1] },
    { id: "efes-fbb", cat: "basketbol", league: "Türkiye Sigorta BSL", home: "Anadolu Efes", away: "Fenerbahçe Beko", homeShort: "EFS", awayShort: "FBB", time: "19:00", status: "live", clock: "Ç2", period: "2. çeyrek", score: [38, 35] },
    { id: "vak-ecz", cat: "voleybol", league: "Sultanlar Ligi", home: "VakıfBank", away: "Eczacıbaşı Dynavit", homeShort: "VKF", awayShort: "ECZ", time: "18:00", status: "live", clock: "S4", period: "4. set", score: [2, 1] },
    { id: "gs-fb", cat: "futbol", league: "Trendyol Süper Lig", home: "Galatasaray", away: "Fenerbahçe", homeShort: "GS", awayShort: "FB", time: "20:00", status: "upcoming", clock: "", period: "Bugün 20.00", score: null, derby: true },
    { id: "hlk-zir", cat: "voleybol", league: "AXA Sigorta Efeler Ligi", home: "Halkbank", away: "Ziraat Bankkart", homeShort: "HLK", awayShort: "ZİR", time: "21:00", status: "upcoming", clock: "", period: "Bugün 21.00", score: null },
    { id: "rac-bel", cat: "futbol", league: "Arjantin Primera División", home: "Racing Club", away: "Belgrano", homeShort: "RAC", awayShort: "BEL", time: "01:15", status: "upcoming", clock: "", period: "Gece 01.15", score: null },
    { id: "bah-mir", cat: "futbol", league: "Brezilya Serie A", home: "Bahia", away: "Mirassol", homeShort: "BAH", awayShort: "MIR", time: "01:30", status: "upcoming", clock: "", period: "Gece 01.30", score: null },
    { id: "cle-orl", cat: "basketbol", league: "NBA Hazırlık", home: "Cleveland Cavaliers", away: "Orlando Magic", homeShort: "CLE", awayShort: "ORL", time: "02:30", status: "upcoming", clock: "", period: "Gece 02.30", score: null },
    { id: "mil-cha", cat: "basketbol", league: "NBA Hazırlık", home: "Milwaukee Bucks", away: "Charlotte Hornets", homeShort: "MIL", awayShort: "CHA", time: "03:00", status: "upcoming", clock: "", period: "Gece 03.00", score: null },
    { id: "eyp-goz", cat: "futbol", league: "Trendyol Süper Lig", home: "Eyüpspor", away: "Göztepe", homeShort: "EYP", awayShort: "GÖZ", time: "17:00", status: "finished", clock: "MS", period: "Maç sonu", score: [2, 1] },
  ],

  channels: [
    { id: "ch-1", no: "01", name: "Ersoy 1", genre: "Futbol", cat: "futbol", now: "Beşiktaş – Trabzonspor", next: "Maç sonu: Ersoy kornerleri tek tek sayıyor", progress: 0.38, matchId: "bjk-ts" },
    { id: "ch-2", no: "02", name: "Ersoy 2", genre: "Basketbol", cat: "basketbol", now: "Anadolu Efes – Fenerbahçe Beko", next: "02.30 · Cavaliers – Magic", progress: 0.46, matchId: "efes-fbb" },
    { id: "ch-3", no: "03", name: "Ersoy 3", genre: "Voleybol", cat: "voleybol", now: "VakıfBank – Eczacıbaşı Dynavit", next: "21.00 · Halkbank – Ziraat Bankkart", progress: 0.81, matchId: "vak-ecz" },
    { id: "ch-4", no: "04", name: "Ersoy MAX", genre: "Derbi kanalı", cat: "futbol", now: "Real Madrid – Barcelona", next: "20.00 · Galatasaray – Fenerbahçe", progress: 0.79, matchId: "rma-bar", feature: true },
    { id: "ch-5", no: "05", name: "Ersoy Klasik", genre: "Efsane maçlar", cat: "kanal", now: "Unutulmaz derbiler (tekrar)", next: "Ersoy'un en sevdiği 0–0'lar", progress: 0.22 },
    { id: "ch-6", no: "06", name: "Ersoy Yorum", genre: "Stüdyo", cat: "kanal", now: "Ersoy topun neden yuvarlak olduğunu anlatıyor", next: "Konuk: Hakemin çorabı", progress: 0.55 },
  ],

  // Hero film karesindeki altyazılar (iki satır)
  subtitles: [
    ["— Neden kafes taktın?", "— Maç heyecanlı olacak dediler."],
    ["— Maç kaçta başlıyor?", "— 20.00'de. 20.01'de başlamış olur."],
    ["— Hangi takımı tutuyorsun?", "— Kazananı. Maçtan sonra söylerim."],
    ["— Gol oldu mu?", "— Oldu gibi. Tekrarına bakalım."],
    ["— Yayın dondu mu?", "— Hayır. Ben dondum. Heyecandan."],
    ["— Rahat mısın?", "— Kafam çok rahat."],
  ],

  // Kayan amber bant
  quotes: [
    "Top yuvarlak. Kontrol ettim.",
    "Ofsaytı anlamadım ama saygı duyuyorum.",
    "Uzatma dakikası var, kısaltma neden yok?",
    "Penaltıda nefesimi tuttum. Hâlâ tutuyorum.",
    "Hakem düdük çaldı. Ben de çaldım. Komşu geldi.",
    "Beraberlik de bir sonuçtur. Kimse üzülmesin.",
    "Korner bayrağını saydım. Dört tane. Hep dört.",
  ],

  // Oynatıcı canlıyken alt bantta dönen yorumlar
  liveComments: [
    "Top şu an orta sahada. Güzel bir yer.",
    "Sağ bek koşuyor. Nedenini bilmiyorum ama destekliyorum.",
    "Hakem bir şey gösterdi. Ne gösterdiğini göremedim.",
    "Kaleci eldivenini düzeltti. Ben de düzelttim. Benim eldivenim yok.",
    "Taç atışı. Taç var ama kral yok. Düşündürücü.",
  ],

  // Oynatıcı altındaki canlı anlatım (en yeni üstte; ago = kaç dakika önce)
  commentary: [
    { ago: 1, text: "Bir oyuncu ayakkabısını bağladı. Çift düğüm. Takdir ettim." },
    { ago: 4, text: "Hakem saatine baktı. Ben de baktım. Aynı saat." },
    { ago: 9, text: "Top dışarı çıktı, geri geldi. Sevindim." },
    { ago: 15, text: "Tribün bir şarkı söylüyor. Sözlerini bilmiyorum ama ritim güzel." },
    { ago: 22, text: "Kenarda biri ısınıyor. Hava soğuk değil. Merak ettim." },
    { ago: 34, text: "Yayın başladı. Kontrol ettim. İki kere." },
    { ago: 41, text: "Isınma bitti. Ben ısınmadım. Gerek yok, oynamıyorum." },
    { ago: 47, text: "Takımlar sahaya çıktı. Saydım: yirmi iki. Hakemle yirmi üç." },
    { ago: 53, text: "Stadyumun ışıkları yandı. Ben de lambayı yaktım. Aynı anda." },
    { ago: 58, text: "Maç öncesi çayımı demledim. 90+5 dakika yeter dediler." },
  ],

  // Skorbord şeridindeki Ersoy notları
  tickerNotes: [
    "Skorları tek tek kontrol ettim. Hepsi doğru.",
    "Derbi 20.00'de. 19.59'da hazır olun.",
    "Dakikaları da saydım. Sorun yok.",
  ],

  derby: {
    matchId: "gs-fb",
    kickoff: "20:00",
    prediction: "Tahminim 1–1. Değilse de bir skor olacak, orası kesin.",
  },

  /*
    REKLAMLAR
    index.html'deki her .ad__frame bir reklam slotudur. İçine gerçek reklam kodu
    (ör. AdSense) yapıştırırsan ads.js o slota dokunmaz. Boş slotlara aşağıdaki
    temalı ev/parodi reklamlardan biri basılır. Markalar kurgusaldır.
  */
  ads: {
    creatives: {
      "kafes-kask": { brand: "Kafes Kask", tagline: "Maç heyecanına karşı tam koruma.", note: "Ersoy onaylı. Kendisi de takıyor.", cta: "Kafanı koru", icon: "i-crest", tone: "amber" },
      "sabir-cayi": { brand: "Sabır Çayı", tagline: "90+5 dakika demlenir.", note: "Uzatmalar dahil.", cta: "Demlemeye başla", icon: "i-tea", tone: "tomato", serif: true },
      "detay-optik": { brand: "Detay Optik", tagline: "Ofsaytı göremiyor musunuz?", note: "Biz de göremiyoruz. Ama gözlüklerimiz güzel.", cta: "Gözlük seç", icon: "i-glasses", tone: "teal" },
      "derbi-smokin": { brand: "Derbi Smokin", tagline: "Derbiye smokinle gelinir.", note: "Sormayın. Kiralık da var.", cta: "Prova et", icon: "i-bowtie", tone: "cream", serif: true },
      "ersoy-corap": { brand: "Ersoy Çorap", tagline: "Hakemlerin tercihi.", note: "Ersoy fark etti. Siz de edeceksiniz.", cta: "Bir çift al", icon: "i-sock", tone: "amber" },
    },

    // "BU ALAN KİRALIK" bannerları: Ersoy fotoğrafı + kiralık tabelası.
    // Her slota sırayla farklı metin, renk ve fotoğraf düşer (yan yana tekrar etmez).
    rent: {
      href: "#iletisim",
      photos: [
        { src: "assets/img/ersoy-smokin.jpg", focus: "50% 18%" },
        { src: "assets/img/ersoy-kafes.jpg", focus: "50% 24%" },
      ],
      tones: ["amber", "tomato", "teal", "cream"],
      copies: [
        { brand: "Bu alan kiralık", tagline: "Markanız burada, Ersoy'un hemen yanında.", note: "Ersoy burayı ölçtü. İki kere.", cta: "Hemen kirala" },
        { brand: "Reklamınız burada", tagline: "Ersoy baktı: burası boş.", note: "Boş kalması ona da garip geliyor.", cta: "İletişime geç" },
        { brand: "Bu alan sizi bekliyor", tagline: "Günlük, haftalık, aylık kiralama.", note: "Ersoy fiyatları hesapladı. Size de söyler.", cta: "Fiyat al" },
        { brand: "Kiralık reklam alanı", tagline: "Maçı izleyen herkes buraya da bakar.", note: "Ersoy öyle diyor. Saymış.", cta: "Reklam ver" },
        { brand: "Bu alan boş", tagline: "Ersoy buraya bir şey koymak istedi, koyamadı.", note: "Siz koyabilirsiniz.", cta: "Yerini ayırt" },
        { brand: "Vitrin sizin", tagline: "Derbi günü burası çok kalabalık olur.", note: "Ersoy smokinle bekliyor.", cta: "Kirala" },
      ],
    },

    // Slot → reklamlar. "kiralik" = Ersoy'lu kiralık banner; liste = parodi markalar.
    // Sıra = doldurma önceliği (aynı anda görünen alanlar önce dolar).
    slots: {
      "video-ust": "kiralik",
      "ust-banner": "kiralik",
      "sol-ray": "kiralik",
      "sag-ray": "kiralik",
      "video-alt": "kiralik",
      "fikstur-kutu": "kiralik",
      "mac-arasi": "kiralik",
      "yayin-sonrasi": "kiralik",
      "kose-kutu": "kiralik",
      "alt-billboard": "kiralik",
      "mobil-alt": "kiralik",
      "kanal-native": ["sabir-cayi", "kafes-kask", "ersoy-corap"],
    },
    playerSponsor: "sabir-cayi",
    ticker: ["Sabır Çayı — 90+5 dakika demlenir.", "Kafes Kask — Maç heyecanına karşı tam koruma."],
    clickNote: "Bu reklamı Ersoy da tıkladı. Bir şey olmadı. (Şablon reklam — gerçek bağlantıyı sen ekleyeceksin.)",
  },
});
